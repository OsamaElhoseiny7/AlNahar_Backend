const express = require('express');
const router = express.Router();
const {
  trackOrder,
  createOrder,
  updateOrderStage,
} = require('../controllers/orderController');

router.route('/').post(createOrder);
router.route('/track/:batchNumber').get(trackOrder);
router.route('/:id/stage').put(updateOrderStage);

module.exports = router;